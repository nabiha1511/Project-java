package contact;

public class min {

}
