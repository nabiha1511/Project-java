package contact;

import java.util.*;
public class ContactBookApp {

    // ===== Contact Class =====
    static class Contact {
        private String name;
        private String phoneNumber;
        private String email;

        public Contact(String name, String phoneNumber, String email) {
            this.name = name;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        public String getName() { return name; }
        public String getPhoneNumber() { return phoneNumber; }
        public String getEmail() { return email; }

        @Override
        public String toString() {
            return "Name: " + name + "\nPhone: " + phoneNumber + "\nEmail: " + email;
        }
    }

    // ===== ContactBook Class =====
    static class ContactBook {
        private Map<String, Contact> contacts;

        public ContactBook() {
            contacts = new TreeMap<>();
        }

        public boolean addContact(Contact contact) {
            String key = contact.getName().toLowerCase();
            if (contacts.containsKey(key)) {
                return false; // Duplicate contact
            }
            contacts.put(key, contact);
            return true;
        }

        public boolean deleteContact(String name) {
            return contacts.remove(name.toLowerCase()) != null;
        }

        public Contact searchContact(String name) {
            return contacts.get(name.toLowerCase());
        }

        public void displayAllContacts() {
            if (contacts.isEmpty()) {
                System.out.println("No contacts found.");
            } else {
                for (Contact contact : contacts.values()) {
                    System.out.println("----------------------");
                    System.out.println(contact);
                }
            }
        }
    }

    // ===== Main Method =====
    public static void main(String[] args) {
        ContactBook contactBook = new ContactBook();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Contact Book ---");
            System.out.println("1. Add Contact");
            System.out.println("2. Delete Contact");
            System.out.println("3. Search Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();

                    Contact contact = new Contact(name, phone, email);
                    if (contactBook.addContact(contact)) {
                        System.out.println("Contact added successfully.");
                    } else {
                        System.out.println("Contact already exists.");
                    }
                    break;

                case 2:
                    System.out.print("Enter name to delete: ");
                    String delName = scanner.nextLine();
                    if (contactBook.deleteContact(delName)) {
                        System.out.println("Contact deleted.");
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter name to search: ");
                    String searchName = scanner.nextLine();
                    Contact found = contactBook.searchContact(searchName);
                    if (found != null) {
                        System.out.println("Contact found:");
                        System.out.println(found);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;

                case 4:
                    contactBook.displayAllContacts();
                    break;

                case 5:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        } while (choice != 5);

        scanner.close();
    }
}

